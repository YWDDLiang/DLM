#!/usr/bin/env python3
"""Run CrysLLMGen diffusion refinement on DLM proposal graphs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import torch
import torch.distributed as dist
from torch.utils.data import Dataset
from tqdm import tqdm


def setup_crysllmgen_imports(crysllmgen_dir: Path):
    sys.path.insert(0, str(crysllmgen_dir.resolve()))
    from config import config
    from models_ddpm.diffusion import CSPDiffusion
    from torch_geometric.data import Data, DataLoader

    return config, CSPDiffusion, Data, DataLoader


def init_distributed() -> Dict[str, Any]:
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    distributed = world_size > 1
    if distributed:
        if not torch.cuda.is_available():
            raise RuntimeError("Distributed refinement requires CUDA.")
        dist.init_process_group(backend="nccl")
        local_rank = int(os.environ.get("LOCAL_RANK", "0"))
        torch.cuda.set_device(local_rank)
        device = torch.device("cuda", local_rank)
        rank = dist.get_rank()
    else:
        rank = 0
        local_rank = 0
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return {
        "distributed": distributed,
        "rank": rank,
        "local_rank": local_rank,
        "world_size": world_size,
        "device": device,
        "is_main": rank == 0,
    }


def lattices_to_params_shape(lattices: torch.Tensor):
    lengths = torch.sqrt(torch.sum(lattices**2, dim=-1))
    angles = torch.zeros_like(lengths)
    for i in range(3):
        j = (i + 1) % 3
        k = (i + 2) % 3
        cos_angle = torch.sum(lattices[..., j, :] * lattices[..., k, :], dim=-1) / (
            lengths[..., j] * lengths[..., k]
        )
        angles[..., i] = torch.clamp(cos_angle, -1.0, 1.0)
    return lengths, torch.arccos(angles) * 180.0 / np.pi


class ProposalDataset(Dataset):
    def __init__(
        self,
        proposal_graphs: List[Dict],
        Data,
        *,
        seed_from_graph_field: str | None = None,
    ):
        self.proposal_graphs = proposal_graphs
        self.Data = Data
        self.seed_from_graph_field = seed_from_graph_field

    def __len__(self) -> int:
        return len(self.proposal_graphs)

    def __getitem__(self, index):
        s = self.proposal_graphs[index]
        n_atom = int(torch.as_tensor(s["n_atom"]).view(-1)[0].item())
        payload = dict(
            num_atoms=torch.LongTensor([n_atom]),
            num_nodes=n_atom,
            num_bonds=s["edge_indices"].shape[0],
            lengths=torch.as_tensor(s["length"], dtype=torch.float32).view(1, 3),
            angles=torch.as_tensor(s["angle"], dtype=torch.float32).view(1, 3),
            frac_coords=torch.as_tensor(s["x_coord"], dtype=torch.float32),
            atom_types=torch.LongTensor(s["a_type"]),
            edge_index=torch.LongTensor(s["edge_indices"].T).contiguous(),
            to_jimages=torch.LongTensor(s["to_jimages"]),
            sample_idx=torch.LongTensor([int(s.get("sample_idx", index))]),
        )
        if self.seed_from_graph_field:
            if self.seed_from_graph_field not in s:
                raise KeyError(
                    f"proposal lacks seed field {self.seed_from_graph_field!r}"
                )
            payload["refiner_seed"] = torch.LongTensor(
                [int(s[self.seed_from_graph_field])]
            )
        return self.Data(**payload)


def write_json(path: Path, payload) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def file_digest(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4*1024*1024),b''):
            digest.update(chunk)
    return digest.hexdigest()


def frozen_seeded_batches(graphs, Data, DataLoader, seed_field):
    """Match the frozen H1 request loop, including DataLoader RNG consumption."""
    for graph in graphs:
        seed = graph.get(seed_field)
        if type(seed) is not int or not 0 <= seed < 2**63:
            raise ValueError('frozen refiner request lacks its original integer noise seed')
        random.seed(seed)
        np.random.seed(seed % (2**32))
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # The historical runner creates this iterator after reseeding. Moving
        # reseeding after fetching a batch would change the diffusion noise.
        dataset = ProposalDataset([graph], Data, seed_from_graph_field=seed_field)
        yield next(iter(DataLoader(dataset, batch_size=1, shuffle=False)))


def empty_payload(num_evals: int) -> Dict[str, torch.Tensor | float]:
    return {
        "frac_coords": torch.empty((num_evals, 0, 3), dtype=torch.float32),
        "num_atoms": torch.empty((num_evals, 0), dtype=torch.long),
        "atom_types": torch.empty((num_evals, 0), dtype=torch.long),
        "lengths": torch.empty((num_evals, 0, 3), dtype=torch.float32),
        "angles": torch.empty((num_evals, 0, 3), dtype=torch.float32),
        "sample_indices": torch.empty((0,), dtype=torch.long),
        "time": 0.0,
    }


def merge_distributed_outputs(output_dir: Path, world_size: int, total_proposals: int, diff_steps: int, num_evals: int) -> None:
    payloads: List[Dict[str, Any]] = []
    assigned_total = 0
    wall_time = 0.0
    for rank in range(world_size):
        metrics_path = output_dir / f"refinement_metrics.rank{rank}.json"
        if not metrics_path.exists():
            continue
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        assigned_total += int(metrics.get("assigned_proposals", 0))
        wall_time = max(wall_time, float(metrics.get("time_sec") or 0.0))
        output_file = Path(metrics["output_file"])
        if output_file.exists():
            payloads.append(torch.load(output_file, map_location="cpu"))

    if payloads:
        payload = {
            "frac_coords": torch.cat([item["frac_coords"] for item in payloads], dim=1),
            "num_atoms": torch.cat([item["num_atoms"] for item in payloads], dim=1),
            "atom_types": torch.cat([item["atom_types"] for item in payloads], dim=1),
            "lengths": torch.cat([item["lengths"] for item in payloads], dim=1),
            "angles": torch.cat([item["angles"] for item in payloads], dim=1),
            "sample_indices": torch.cat(
                [
                    item.get("sample_indices", torch.arange(item["num_atoms"].shape[1], dtype=torch.long))
                    for item in payloads
                ],
                dim=0,
            ),
            "time": wall_time,
        }
    else:
        payload = empty_payload(num_evals)
        payload["time"] = wall_time

    output_file = output_dir / f"dlm_refined_mp_{assigned_total}.pt"
    torch.save(payload, output_file)
    write_json(
        output_dir / "refinement_metrics.json",
        {
            "num_proposals": total_proposals,
            "assigned_proposals": assigned_total,
            "output_file": str(output_file),
            "time_sec": wall_time,
            "diff_steps": diff_steps,
            "num_evals": num_evals,
            "distributed": True,
            "world_size": world_size,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proposal-graphs", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--crysllmgen-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=27017)
    parser.add_argument("--seed-by-sample-index", action="store_true")
    parser.add_argument("--seed-from-graph-field", default=None)
    parser.add_argument('--frozen-single-request-seeding', action='store_true',
                        help='Use the original H1 per-request seed-before-DataLoader protocol')
    parser.add_argument("--timesteps", type=int, default=1000)
    parser.add_argument("--diff-steps", type=int, default=800)
    parser.add_argument("--num-evals", type=int, default=1)
    parser.add_argument("--run-type", default="train")
    parser.add_argument("--max-proposals", type=int, default=1000)
    args = parser.parse_args()

    if args.frozen_single_request_seeding:
        if (not args.seed_from_graph_field or args.seed_by_sample_index or args.batch_size != 1
                or args.num_evals != 1 or args.diff_steps != 800 or args.timesteps != 1000):
            raise ValueError('frozen refinement requires original graph seeds, batch=1, one draw, and 800/1000 steps')
        digest = hashlib.sha256()
        with args.checkpoint.open('rb') as stream:
            for chunk in iter(lambda: stream.read(4*1024*1024), b''):
                digest.update(chunk)
        if digest.hexdigest() != '573e9b10af64b266b7c6cde4d0f8bdd8a7388fa98d36e2e82db341af3e511e7e':
            raise ValueError('frozen refinement model494 checkpoint identity changed')

    args.output_dir.mkdir(parents=True, exist_ok=True)
    dist_info = init_distributed()
    rank = dist_info["rank"]
    world_size = dist_info["world_size"]
    distributed = dist_info["distributed"]
    is_main = dist_info["is_main"]
    if is_main:
        run_config = {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()}
        run_config["distributed"] = distributed
        run_config["world_size"] = world_size
        if args.frozen_single_request_seeding:
            run_config.update(seed_mode='frozen_h1_ordinal_refiner_noise_seed',effective_batch_size=1,
                seed_before_dataloader=True,checkpoint_sha256=digest.hexdigest(),runner_sha256=file_digest(__file__),
                proposal_graphs_sha256=file_digest(args.proposal_graphs),
                frozen_seed_ledger_sha256=file_digest(args.proposal_graphs.parent/'attempt_ledger.jsonl'))
        write_json(args.output_dir / "run_config.json", run_config)
        with (args.output_dir / "training_log.jsonl").open("w", encoding="utf-8") as handle:
            handle.write(
                json.dumps(
                    {
                        "event": "not_applicable",
                        "stage": "diffusion_refinement",
                        "reason": "refinement run; no optimizer training is performed",
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )

    config, CSPDiffusion, Data, DataLoader = setup_crysllmgen_imports(args.crysllmgen_dir)
    device = dist_info["device"]

    proposal_graphs = torch.load(args.proposal_graphs, map_location="cpu")
    if args.frozen_single_request_seeding:
        ledger = [json.loads(line) for line in (args.proposal_graphs.parent/'attempt_ledger.jsonl').read_text().splitlines()]
        if [row.get('sample_idx') for row in ledger] != list(range(len(ledger))):
            raise ValueError('frozen main refiner seed ledger is not in complete original order')
        graph_ids = [int(graph['sample_idx']) for graph in proposal_graphs]
        if (len(set(graph_ids)) != len(graph_ids) or any(not 0 <= index < len(ledger) for index in graph_ids)
                or any(graph.get(args.seed_from_graph_field) != ledger[int(graph['sample_idx'])]['refiner_noise_seed']
                       for graph in proposal_graphs)):
            raise ValueError('frozen main refiner graph seeds differ from the original request ledger')
    if args.frozen_single_request_seeding and args.max_proposals and len(proposal_graphs) > args.max_proposals:
        raise ValueError('frozen main refinement cannot truncate its original request graphs')
    if args.max_proposals:
        proposal_graphs = proposal_graphs[: args.max_proposals]
    total_proposals = len(proposal_graphs)
    rank_graphs = proposal_graphs[rank::world_size] if distributed else proposal_graphs
    if args.seed_by_sample_index and args.seed_from_graph_field:
        raise ValueError(
            "choose either --seed-by-sample-index or --seed-from-graph-field"
        )
    dataset = ProposalDataset(
        rank_graphs,
        Data,
        seed_from_graph_field=args.seed_from_graph_field,
    )
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)

    model = CSPDiffusion(args.timesteps, args.run_type).to(device)
    model.device = device
    checkpoint = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(checkpoint["model"] if "model" in checkpoint else checkpoint)
    model.eval()
    rank_seed = int(args.seed) + int(rank)
    np.random.seed(rank_seed)
    torch.manual_seed(rank_seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(rank_seed)

    frac_coords_all, num_atoms_all, atom_types_all, lattices_all, sample_indices_all = [], [], [], [], []
    start = time.time()
    with torch.no_grad():
        batches = (frozen_seeded_batches(rank_graphs,Data,DataLoader,args.seed_from_graph_field)
                   if args.frozen_single_request_seeding else dataloader)
        for batch in tqdm(batches, total=len(rank_graphs) if args.frozen_single_request_seeding else len(dataloader),
                          desc=f"CrysLLMGen refinement rank{rank}", disable=distributed and not is_main):
            batch = batch.to(device)
            if (
                args.seed_by_sample_index or args.seed_from_graph_field
            ) and int(batch.num_graphs) != 1:
                raise ValueError("per-branch deterministic seeding requires --batch-size 1")
            batch_frac, batch_num, batch_atom, batch_lat = [], [], [], []
            sample_idx = int(batch.sample_idx.view(-1)[0].item())
            for eval_idx in range(args.num_evals):
                if args.seed_from_graph_field and not args.frozen_single_request_seeding:
                    sample_seed = int(batch.refiner_seed.view(-1)[0].item()) + eval_idx
                    np.random.seed(sample_seed)
                    torch.manual_seed(sample_seed)
                    if torch.cuda.is_available():
                        torch.cuda.manual_seed_all(sample_seed)
                elif args.seed_by_sample_index:
                    sample_seed = int(args.seed) + sample_idx * max(1, int(args.num_evals)) + eval_idx
                    np.random.seed(sample_seed)
                    torch.manual_seed(sample_seed)
                    if torch.cuda.is_available():
                        torch.cuda.manual_seed_all(sample_seed)
                outputs, _ = model.sample(batch, diff_steps=args.diff_steps)
                batch_frac.append(outputs["frac_coords"].detach().cpu())
                batch_num.append(outputs["num_atoms"].detach().cpu())
                batch_atom.append(outputs["atom_types"].detach().cpu())
                batch_lat.append(outputs["lattices"].detach().cpu())
            frac_coords_all.append(torch.stack(batch_frac))
            num_atoms_all.append(torch.stack(batch_num))
            atom_types_all.append(torch.stack(batch_atom))
            lattices_all.append(torch.stack(batch_lat))
            sample_indices_all.append(batch.sample_idx.detach().cpu().view(-1))

    elapsed = time.time() - start
    output_file = (
        args.output_dir / f"dlm_refined_mp_{len(rank_graphs)}.rank{rank}.pt"
        if distributed
        else args.output_dir / f"dlm_refined_mp_{len(rank_graphs)}.pt"
    )
    if frac_coords_all:
        frac_coords = torch.cat(frac_coords_all, dim=1)
        num_atoms = torch.cat(num_atoms_all, dim=1)
        atom_types = torch.cat(atom_types_all, dim=1)
        lattices = torch.cat(lattices_all, dim=1)
        lengths, angles = lattices_to_params_shape(lattices)
        payload = {
            "frac_coords": frac_coords,
            "num_atoms": num_atoms,
            "atom_types": atom_types,
            "lengths": lengths,
            "angles": angles,
            "sample_indices": torch.cat(sample_indices_all, dim=0),
            "time": elapsed,
        }
    else:
        payload = empty_payload(args.num_evals)
        payload["time"] = elapsed
    torch.save(payload, output_file)

    metrics_name = f"refinement_metrics.rank{rank}.json" if distributed else "refinement_metrics.json"
    write_json(
        args.output_dir / metrics_name,
        {
            "num_proposals": total_proposals,
            "assigned_proposals": len(rank_graphs),
            "output_file": str(output_file),
            "time_sec": elapsed,
            "diff_steps": args.diff_steps,
            "num_evals": args.num_evals,
            "distributed": distributed,
            "rank": rank,
            "world_size": world_size,
        },
    )
    if is_main:
        with (args.output_dir / "training_log.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(
                    {
                        "event": "refinement_complete",
                        "assigned_proposals": len(rank_graphs),
                        "time_sec": elapsed,
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )

    if distributed:
        dist.barrier()
        if is_main:
            merge_distributed_outputs(args.output_dir, world_size, total_proposals, args.diff_steps, args.num_evals)
        dist.barrier()
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
