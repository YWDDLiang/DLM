#!/usr/bin/env python
from __future__ import annotations

import logging
import os
from os.path import dirname, exists, join, realpath
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

import pytest
from ase.spacegroup import Spacegroup
from ase.spacegroup import crystal as ase_crystal
from pymatgen.core import Lattice as PmgLattice
from pymatgen.core import Structure
from pymatgen.core.periodic_table import Specie

import smact
import smact.lattice
import smact.lattice_parameters
import smact.oxidation_states
import smact.screening
from smact import Species, distorter
from smact.builder import cubic_perovskite, wurtzite
from smact.properties import (
    band_gap_Harrison,
    compound_electroneg,
    eneg_mulliken,
    valence_electron_count,
)

files_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "files")
TEST_OX_STATES = os.path.join(files_dir, "test_oxidation_states.txt")
TEST_STRUCT = os.path.join(files_dir, "mp-540839_CsPbI3_oxi.json")


class TestSequenceFunctions:
    # ---------------- TOP-LEVEL ----------------

    def test_Element_class_Pt(self):
        Pt = smact.Element(
            "Pt",
        )
        assert Pt.name == "Platinum"
        assert Pt.ionpot == 8.95883
        assert Pt.number == 78
        assert Pt.dipol == 44.00

    def test_ordered_elements(self):
        assert smact.ordered_elements(65, 68) == ["Tb", "Dy", "Ho", "Er"]
        assert smact.ordered_elements(52, 52) == ["Te"]

    def test_element_dictionary(self):
        newlist = ["O", "Rb", "W"]
        dictionary = smact.element_dictionary(newlist, TEST_OX_STATES)
        assert dictionary["O"].crustal_abundance == 461000.0
        assert dictionary["Rb"].oxidation_states_smact14 == [-1, 1]
        assert dictionary["Rb"].oxidation_states == [1]
        assert dictionary["Rb"].oxidation_states_custom == [-1, 1]
        assert dictionary["W"].name == "Tungsten"
        assert "Rn" in smact.element_dictionary()

    def test_are_eq(self):
        assert smact.are_eq([1.00, 2.00, 3.00], [1.001, 1.999, 3.00], tolerance=1e-2)
        assert not smact.are_eq([1.00, 2.00, 3.00], [1.001, 1.999, 3.00])

    def test_gcd_recursive(self):
        assert smact._gcd_recursive(4, 12, 10, 32) == 2
        assert smact._gcd_recursive(15, 4) == 1

    def test_isneutral(self):
        assert smact._isneutral((-2, 1), (2, 4))
        assert not smact._isneutral((4, -1), (1, 3))

    def test_neutral_ratios(self):
        ox = [1, -2, 1]
        neutral_combos = smact.neutral_ratios(ox)
        assert len(neutral_combos) == 9
        assert (3, 2, 1) in neutral_combos

    # ---------------- Properties ----------------

    def test_compound_eneg_brass(self):
        assert compound_electroneg(elements=["Cu", "Zn"], stoichs=[0.5, 0.5], source="Pauling") == pytest.approx(
            5.0638963259,
        )

    def test_harrison_gap_MgCl(self):
        assert band_gap_Harrison("Mg", "Cl", distance=2.67) == pytest.approx(
            3.545075110572662,
        )

    def test_valence_electron_count(self):
        # Test valid compounds
        assert valence_electron_count("Fe2O3") == pytest.approx(6.8, abs=1e-2)
        assert valence_electron_count("CuZn") == pytest.approx(11.5, abs=1e-2)

        # Test single element
        assert valence_electron_count("Fe") == 8

        # Test empty string
        assert valence_electron_count("") == 0.0

        # Test invalid elements and formats
        with pytest.raises(ValueError):
            valence_electron_count("Xx2O3")  # Xx is not a real element

        with pytest.raises(ValueError):
            valence_electron_count("LrO")

    # ---------------- BUILDER ----------------

    def test_builder_ZnS(self):
        ZnS, _ = wurtzite(["Zn", "S"])
        assert (ZnS.sites[0].position[2]) == 0
        assert (ZnS.sites[0].position[0]) == 2.0 / 3.0

    # ---------------- SCREENING ----------------

    def test_pauling_test(self):
        Sn, S = (smact.Element(label) for label in ("Sn", "S"))
        assert smact.screening.pauling_test(
            (+2, -2),
            (Sn.pauling_eneg, S.pauling_eneg),
        )
        assert not smact.screening.pauling_test((-2, +2), (Sn.pauling_eneg, S.pauling_eneg))
        assert not smact.screening.pauling_test(
            (-2, -2, +2),
            (S.pauling_eneg, S.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "S", "Sn"),
            repeat_anions=False,
        )
        assert smact.screening.pauling_test(
            (-2, -2, +2),
            (S.pauling_eneg, S.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "S", "Sn"),
            repeat_cations=False,
        )
        assert not smact.screening.pauling_test(
            (-2, +2, +2),
            (S.pauling_eneg, Sn.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "Sn", "Sn"),
            repeat_cations=False,
        )
        assert smact.screening.pauling_test(
            (-2, +2, +2),
            (S.pauling_eneg, Sn.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "Sn", "Sn"),
            repeat_anions=False,
        )

    def test_eneg_states_test(self):
        Na, Fe, Cl = (smact.Element(label) for label in ("Na", "Fe", "Cl"))
        assert smact.screening.eneg_states_test([1, 3, -1], [Na.pauling_eneg, Fe.pauling_eneg, Cl.pauling_eneg])
        assert not smact.screening.eneg_states_test([-1, 3, 1], [Na.pauling_eneg, Fe.pauling_eneg, Cl.pauling_eneg])

    def test_eneg_states_test_threshold(self):
        assert not smact.screening.eneg_states_test_threshold([1, -1], [1.83, 1.82], threshold=0)
        assert smact.screening.eneg_states_test_threshold([1, -1], [1.83, 1.82], threshold=0.1)

    def test_ml_rep_generator(self):
        Pb, o_elem = (smact.Element(label) for label in ("Pb", "O"))
        PbO2_ml = [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.6666666666666666,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.3333333333333333,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,  # element 103 (Lr)
        ]
        assert smact.screening.ml_rep_generator(["Pb", "O"], [1, 2]) == PbO2_ml
        assert smact.screening.ml_rep_generator([Pb, o_elem], [1, 2]) == PbO2_ml

    def test_smact_filter(self):
        oxidation_states_sets = ["smact14", "icsd24"]
        oxidation_states_sets_results = {
            "smact14": {
                "thresh_2": [
                    (("Na", "Fe", "Cl"), (1, -1, -1), (2, 1, 1)),
                    (("Na", "Fe", "Cl"), (1, 1, -1), (1, 1, 2)),
                ]
            },
            "icsd24": {"thresh_2": [(("Na", "Fe", "Cl"), (1, 1, -1), (1, 1, 2))]},
        }

        Na, Fe, Cl = (smact.Element(label) for label in ("Na", "Fe", "Cl"))

        for ox_state_set in oxidation_states_sets:
            output: Any = smact.screening.smact_filter([Na, Fe, Cl], threshold=2, oxidation_states_set=ox_state_set)
            assert [(r[0], r[1], r[2]) for r in output] == oxidation_states_sets_results[ox_state_set]["thresh_2"]

        # Test that reading the oxidation states from a file produces the same results
        assert smact.screening.smact_filter(
            [Na, Fe, Cl], threshold=2, oxidation_states_set="smact14"
        ) == smact.screening.smact_filter([Na, Fe, Cl], threshold=2, oxidation_states_set=TEST_OX_STATES)

        assert set(
            smact.screening.smact_filter(
                [Na, Fe, Cl], threshold=2, species_unique=False, oxidation_states_set="smact14"
            )
        ) == {
            (("Na", "Fe", "Cl"), (2, 1, 1)),
            (("Na", "Fe", "Cl"), (1, 1, 2)),
        }

        assert len(smact.screening.smact_filter([Na, Fe, Cl], threshold=8, oxidation_states_set="smact14")) == 77

        result: Any = smact.screening.smact_filter(
            [Na, Fe, Cl], stoichs=[[1], [1], [4]], oxidation_states_set="smact14"
        )
        assert [(r[0], r[1], r[2]) for r in result] == [
            (("Na", "Fe", "Cl"), (1, 3, -1), (1, 1, 4)),
        ]
        stoichs = [list(range(1, 5)), list(range(1, 5)), list(range(1, 10))]
        assert len(smact.screening.smact_filter([Na, Fe, Cl], stoichs=stoichs, oxidation_states_set="smact14")) == 45

    # --------- New tests for revised screening logic ---------

    def test_smact_validity(self):
        """
        Test that smact_validity returns a boolean indicating whether a composition is valid.
        """
        # Test with a valid composition
        result = smact.screening.smact_validity("NaCl")
        assert isinstance(result, bool)
        assert result

        # Test with an invalid composition
        invalid_result = smact.screening.smact_validity("Al3Li", include_alloys=False)
        assert not invalid_result

    def test_smact_validity_parameters(self):
        """
        Test smact_validity with different parameter combinations
        """
        # Test with pauling test disabled
        result_no_pauling = smact.screening.smact_validity("NaCl", use_pauling_test=False)
        assert result_no_pauling

        # Test with metallicity check
        result_metallicity = smact.screening.smact_validity("Fe", check_metallicity=True, metallicity_threshold=0.1)
        assert result_metallicity

        # Test with different oxidation states set
        result_ox_states = smact.screening.smact_validity("NaCl", oxidation_states_set="icsd16")
        assert result_ox_states

    def test_smact_validity_type_error_forced(self):
        """
        Force the except TypeError block in smact_validity's try/except to be triggered.
        """

        original_pauling_test = smact.screening.pauling_test

        def mock_pauling_test(*args, **kwargs):
            msg = "Mock TypeError triggered"
            raise TypeError(msg)

        try:
            smact.screening.pauling_test = mock_pauling_test
            result = smact.screening.smact_validity("NaCl", use_pauling_test=True)
            assert isinstance(result, bool)
            assert result
        finally:
            smact.screening.pauling_test = original_pauling_test

    def test_smact_validity_noble_gases(self):
        """
        Test that noble gases with no oxidation states return False cleanly
        (no TypeError) regardless of which oxidation_states_set is used.
        """
        for ox_set in ["smact14", "icsd16", "icsd24", "pymatgen_sp"]:
            assert not smact.screening.smact_validity("NeF2", oxidation_states_set=ox_set), (
                f"NeF2 should be False with oxidation_states_set={ox_set}"
            )
        # Xe and Kr have known oxidation states and should still pass
        assert smact.screening.smact_validity("XeF2")
        assert smact.screening.smact_validity("KrF2")
        # Also verify the explicit oxidation_states_set path (the reported bug case)
        assert smact.screening.smact_validity("XeF2", oxidation_states_set="icsd24")
        assert smact.screening.smact_validity("KrF2", oxidation_states_set="icsd24")

    def test_smact_validity_special_cases(self):
        """
        Test special cases in smact_validity:
        - Single elements
        - Alloys
        - High metallicity
        """
        # Single element should be valid
        assert smact.screening.smact_validity("Fe")

        # Alloy should be valid when include_alloys=True
        assert smact.screening.smact_validity("FeAl", include_alloys=True)

        # High metallicity check
        assert smact.screening.smact_validity(
            "FeNi",
            check_metallicity=True,
            metallicity_threshold=0.5,
            include_alloys=False,  # Test metallicity path specifically
        )

    def test_smact_validity_oxidation_states(self):
        """
        Test various oxidation state sets in smact_validity
        """
        # Test different oxidation state sets
        oxidation_sets = ["smact14", "icsd16", "icsd24", "pymatgen_sp"]
        for ox_set in oxidation_sets:
            assert smact.screening.smact_validity("NaCl", oxidation_states_set=ox_set), (
                f"Failed with oxidation state set: {ox_set}"
            )

        # Test with file path

        files_dir = join(dirname(realpath(__file__)), "files")
        test_ox_states = join(files_dir, "test_oxidation_states.txt")
        assert smact.screening.smact_validity("NaCl", oxidation_states_set=test_ox_states)

    def test_smact_validity_mixed_valence(self):
        """Test mixed valence handling in smact_validity."""
        # Fe3O4: fails without mixed_valence (no single Fe oxidation state works)
        assert not smact.screening.smact_validity("Fe3O4")
        # Fe3O4: passes with mixed_valence=True (Fe2+ + 2*Fe3+ + 4*O2-)
        assert smact.screening.smact_validity("Fe3O4", mixed_valence=True)

        # Mn3O4 (hausmannite): Mn2+Mn3+2O4 — second real mixed-valence compound
        assert smact.screening.smact_validity("Mn3O4", mixed_valence=True)

        # Compounds with no mixed-valence elements: flag has no effect on valid compounds
        assert smact.screening.smact_validity("NaCl", mixed_valence=True)

        # Compound with no mixed-valence elements that fails regardless (Li only has +1, can't balance)
        assert not smact.screening.smact_validity("LiF2", mixed_valence=True)

        # Explicit confirmation of default behaviour (mixed_valence=False)
        assert not smact.screening.smact_validity("Fe3O4", mixed_valence=False)

    def test_smact_validity_error_handling(self):
        """
        Test error handling in smact_validity
        """
        # Test with invalid oxidation states set
        with pytest.raises(ValueError):
            smact.screening.smact_validity("NaCl", oxidation_states_set="invalid_set")

        # Test that wiki set gives warning
        with pytest.warns(UserWarning, match=r"This set of oxidation states is sourced from Wikipedia"):
            smact.screening.smact_validity("NaCl", oxidation_states_set="wiki")

    # ---------------- Lattice ----------------
    def test_Lattice_class(self):
        site_A = smact.lattice.Site([0, 0, 0], -1)
        site_B = smact.lattice.Site([0.5, 0.5, 0.5], [+2, +3])
        test_lattice = smact.lattice.Lattice([site_A, site_B], space_group=221)
        assert test_lattice.sites[0].oxidation_states == [-1]
        assert test_lattice.sites[1].position == [0.5, 0.5, 0.5]

    # ---------- Lattice parameters -----------
    def test_lattice_parameters(self):
        perovskite = smact.lattice_parameters.cubic_perovskite([1.81, 1.33, 1.82])
        wurtz = smact.lattice_parameters.wurtzite([1.81, 1.33])
        assert perovskite[0] == pytest.approx(6.3)
        assert perovskite[1] == pytest.approx(6.3)
        assert perovskite[3] == pytest.approx(90)
        assert wurtz[0] == pytest.approx(5.1276, abs=1e-4)
        assert wurtz[2] == pytest.approx(8.3733, abs=1e-4)

    # ---------- smact.oxidation_states module -----------
    def test_oxidation_states(self):
        ox = smact.oxidation_states.Oxidation_state_probability_finder()
        assert ox.compound_probability([Specie("Fe", +3), Specie("O", -2)]) == pytest.approx(
            0.74280230326,
        )
        assert ox.pair_probability(Species("Fe", +3), Species("O", -2)) == pytest.approx(
            0.74280230326,
        )
        assert len(ox.get_included_species()) == 173

    def test_compound_probability_structure(self):
        structure = Structure.from_file(TEST_STRUCT)
        ox = smact.oxidation_states.Oxidation_state_probability_finder()
        assert ox.compound_probability(structure) == 1.0

    # --------- Additional Coverage Tests (for untested lines in screening) ---------

    def test_smact_validity_oxidation_states_file(self):
        """
        Test that providing a valid file path triggers the file-based combos branch.
        """

        assert exists(TEST_OX_STATES), "TEST_OX_STATES must exist for this test."
        # Test just the validity
        assert smact.screening.smact_validity("NaCl", oxidation_states_set=TEST_OX_STATES)

    # --------- Properties branch coverage ---------

    def test_eneg_mulliken_branches(self):
        """eneg_mulliken: str input, Element input, and invalid type."""
        # str input (line 32)
        val_str = eneg_mulliken("Fe")
        assert isinstance(val_str, float)

        # Element input (line 36)
        val_el = eneg_mulliken(smact.Element("Fe"))
        assert val_str == pytest.approx(val_el)

        # Invalid type raises TypeError (lines 33-34)
        bad_input: Any = 42
        with pytest.raises(TypeError):
            eneg_mulliken(bad_input)

    def test_harrison_gap_logging(self, caplog):
        """band_gap_Harrison always logs debug info."""
        with caplog.at_level(logging.DEBUG, logger="smact.properties"):
            band_gap_Harrison("Mg", "Cl", distance=2.67)
        log_output = caplog.text
        assert "V1_bar" in log_output
        assert "V2" in log_output
        assert "alpha_m" in log_output
        assert "V3" in log_output

    def test_compound_electroneg_element_objects(self, caplog):
        """compound_electroneg with Element objects and logging."""
        Fe = smact.Element("Fe")
        o_elem = smact.Element("O")

        # Element list input + Mulliken
        val = compound_electroneg(elements=[Fe, o_elem], stoichs=[1, 1], source="Mulliken")
        assert isinstance(val, float)

        # Invalid element type raises TypeError
        bad_elements: Any = [42, 43]
        with pytest.raises(TypeError):
            compound_electroneg(elements=bad_elements, stoichs=[1, 1])

        # Invalid source raises ValueError
        with pytest.raises(ValueError):
            compound_electroneg(elements=["Fe", "O"], stoichs=[1, 1], source="BadSource")

        # Always logs debug info now
        with caplog.at_level(logging.DEBUG, logger="smact.properties"):
            compound_electroneg(elements=["Fe", "O"], stoichs=[1, 1])
        log_output = caplog.text
        assert "Electronegativities" in log_output
        assert "Geometric mean" in log_output

    # --------- Builder branch coverage ---------

    def test_cubic_perovskite(self):
        """cubic_perovskite was never tested; covers builder.py lines 41-58."""
        lattice, system = cubic_perovskite(["Ba", "Ti", "O"])
        assert len(lattice.sites) == 5  # 1 Ba + 1 Ti + 3 O
        assert system is not None

    # --------- Oxidation-states branch coverage ---------

    def test_oxidation_states_error_branches(self):
        """OxidationStateProbabilityFinder error paths (lines 80, 88, 151, 161, 182)."""
        ox = smact.oxidation_states.OxidationStateProbabilityFinder()

        # Both positive → ValueError (line 80)
        with pytest.raises(ValueError, match="cation and one anion"):
            ox._generate_lookup_key(Species("Fe", 3), Species("Cu", 2))

        # Both negative → ValueError (line 80)
        with pytest.raises(ValueError, match="cation and one anion"):
            ox._generate_lookup_key(Species("O", -2), Species("S", -2))

        # Species not in table → KeyError (line 88)
        # Fe+5 is a valid smact Species but is absent from the Hautier probability table
        with pytest.raises(KeyError):
            ox._generate_lookup_key(Species("Fe", 5), Species("O", -2))

        # Invalid input type → TypeError (line 151)
        bad_input: Any = "NaCl_string"
        with pytest.raises(TypeError):
            ox.compound_probability(bad_input)

        # No cations in list → ValueError (line 161)
        with pytest.raises(ValueError, match="No cations"):
            ox.compound_probability([Species("O", -2), Species("S", -2)])

        # Unknown module attribute → AttributeError (line 182)
        with pytest.raises(AttributeError):
            _ = smact.oxidation_states.does_not_exist

    def test_oxidation_states_pymatgen_species_input(self):
        """compound_probability with pymatgen Species list (lines 134-138, 142)."""
        ox = smact.oxidation_states.OxidationStateProbabilityFinder()

        # List of pymatgen Species (lines 134-136)
        result = ox.compound_probability([Specie("Fe", 3), Specie("O", -2)])
        assert isinstance(result, float)

        # List with mixed/invalid pymatgen species (line 138) — a list mixing types
        with pytest.raises(TypeError):
            ox.compound_probability([Specie("Fe", 3), "not_a_species"])

        # pymatgen Structure without oxidation states → TypeError (line 142)
        struct = Structure.from_spacegroup("Fm-3m", PmgLattice.cubic(5.6), ["Na", "Cl"], [[0, 0, 0], [0.5, 0.5, 0.5]])
        with pytest.raises(TypeError, match="oxidation states"):
            ox.compound_probability(struct)

    # --------- Screening branch coverage ---------

    def test_pauling_test_threshold_branches(self):
        """pauling_test lines 139 (repeat+threshold) and 150 (no-repeat+threshold)."""
        Sn, S = smact.Element("Sn"), smact.Element("S")

        # Both repeats=True with threshold != 0 → line 139
        result = smact.screening.pauling_test(
            (+2, -2),
            (Sn.pauling_eneg, S.pauling_eneg),
            repeat_anions=True,
            repeat_cations=True,
            threshold=0.5,
        )
        assert isinstance(result, bool)

        # repeat_anions=False, repeat_cations=False, distinct symbols, threshold != 0
        # → _no_repeats line 179 returns True → pauling_test line 150
        result2 = smact.screening.pauling_test(
            (-2, +2),
            (S.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "Sn"),
            repeat_anions=False,
            repeat_cations=False,
            threshold=0.5,
        )
        assert isinstance(result2, bool)

    def test_no_repeats_line_179(self):
        """_no_repeats line 179: repeat_anions=False AND repeat_cations=False → len check."""
        Sn, S = smact.Element("Sn"), smact.Element("S")

        # Both repeat flags False, distinct symbols → _no_repeats line 179 → True → line 148
        result = smact.screening.pauling_test(
            (-2, +2),
            (S.pauling_eneg, Sn.pauling_eneg),
            symbols=("S", "Sn"),
            repeat_anions=False,
            repeat_cations=False,
            threshold=0.0,
        )
        assert isinstance(result, bool)

    def test_ml_rep_generator_no_stoichs(self):
        """ml_rep_generator without explicit stoichs triggers default-stoichs path (line 403)."""
        result = smact.screening.ml_rep_generator(["Na", "Cl"])
        assert len(result) == 103
        assert sum(result) == pytest.approx(1.0)
        # Each element contributes equally when stoichs default to 1
        Na_idx = int(smact.Element("Na").number) - 1
        Cl_idx = int(smact.Element("Cl").number) - 1
        assert result[Na_idx] == pytest.approx(0.5)
        assert result[Cl_idx] == pytest.approx(0.5)

    def test_smact_filter_wiki_warning(self):
        """smact_filter with wiki oxidation_states_set emits a warning (line 487)."""
        Na, Cl = smact.Element("Na"), smact.Element("Cl")
        with pytest.warns(UserWarning, match="Wikipedia"):
            smact.screening.smact_filter([Na, Cl], threshold=2, oxidation_states_set="wiki")

    def test_smact_filter_invalid_set_raises(self):
        """smact_filter with unknown set string raises ValueError (line 494)."""
        Na, Cl = smact.Element("Na"), smact.Element("Cl")
        with pytest.raises(ValueError):
            smact.screening.smact_filter([Na, Cl], oxidation_states_set="nonexistent_set")

    def test_smact_filter_missing_oxidation_states_raises(self):
        """smact_filter raises ValueError when element has no ox states in chosen set (line 501)."""
        # Argon has no oxidation states in icsd24
        Ar, Na = smact.Element("Ar"), smact.Element("Na")
        with pytest.raises(ValueError, match="No oxidation states"):
            smact.screening.smact_filter([Na, Ar], threshold=2, oxidation_states_set="icsd24")

    def test_smact_validity_icsd_filter_config(self):
        """smact_validity accepts ICSD24FilterConfig for filtering (line 561)."""
        config = smact.screening.ICSD24FilterConfig(include_zero=True, consensus=10)
        result = smact.screening.smact_validity("NaCl", icsd_filter=config)
        assert isinstance(result, bool)

    def test_smact_validity_element_not_in_consensus_set(self):
        """smact_validity returns False when element absent from consensus ICSD24 filter (line 609)."""
        # Noble gas with no ICSD entries: Ar not expected in consensus filter
        result = smact.screening.smact_validity("ArNa", oxidation_states_set=None)
        assert not result

    # --------- distorter coverage ---------

    def test_distorter_functions(self):
        """distorter get_sg, build_sub_lattice, get_inequivalent_sites, make_substitution.

        Newer spglib dropped direct ASE Atoms support (returns None), so we patch
        spglib.get_spacegroup to return the canonical Fm-3m string for NaCl.
        """
        # NaCl rocksalt: spacegroup 225 (Fm-3m)
        nacl = ase_crystal(
            ["Na", "Cl"],
            [(0, 0, 0), (0.5, 0.5, 0.5)],
            spacegroup=225,
            cellpar=[5.6, 5.6, 5.6, 90, 90, 90],
        )

        with patch.object(distorter.spglib, "get_spacegroup", return_value="Fm-3m (225)"):
            # get_sg (lines 44-47)
            sg = distorter.get_sg(nacl)
            assert isinstance(sg, Spacegroup)
            assert sg.no == 225

            # build_sub_lattice (lines 132-140) — does not use spglib
            sub_lat = distorter.build_sub_lattice(nacl, "Na")
            assert len(sub_lat) > 0
            assert len(sub_lat[0]) == 3

            # get_inequivalent_sites (lines 69-87) — calls get_sg internally
            ineq = distorter.get_inequivalent_sites(sub_lat, nacl)
            assert len(ineq) > 0

            # make_substitution (lines 105-114) — does not use spglib
            new_lattice = distorter.make_substitution(nacl, sub_lat[0], "K")
            assert "K" in new_lattice.get_chemical_symbols()

            # get_inequivalent_sites line 77: duplicate site → new_site = False
            # Passing the same site twice makes the second pass find a match
            ineq_dup = distorter.get_inequivalent_sites([sub_lat[0], sub_lat[0]], nacl)
            assert len(ineq_dup) == 1

    # --------- __init__.py edge case coverage ---------

    def test_element_custom_oxi_bad_file(self):
        """Element with bad oxi_states_custom_filepath warns and sets None (line 173-175)."""
        with (
            patch(
                "smact.data_loader.lookup_element_oxidation_states_custom",
                side_effect=TypeError("mocked"),
            ),
            pytest.warns(UserWarning, match="Custom oxidation states file not found"),
        ):
            el = smact.Element("Fe", oxi_states_custom_filepath="dummy.txt")
        assert el.oxidation_states_custom is None

    def test_species_extended_radii(self):
        """Species with radii_source='extended' loads ML Shannon radii."""
        sp = Species("Fe", 3, coordination=6, radii_source="extended")
        assert sp.shannon_radius is not None

    def test_species_invalid_radii_source(self):
        """Species with invalid radii_source raises ValueError."""
        with pytest.raises(ValueError, match="not recognised"):
            Species("Fe", 3, radii_source="invalid_source")

    def test_species_sse_2015_property(self):
        """Species SSE_2015 is set when data exists (e.g. Fe3+)."""
        sp = Species("Fe", 3)
        # Fe3+ should have SSE_2015 data
        assert sp.SSE_2015 is not None

    def test_species_no_sse_2015(self):
        """Species SSE_2015 is None when no data exists."""
        # Oxidation state 0 for noble gas — no SSE_2015 data
        sp = Species("Fe", 0)
        assert sp.SSE_2015 is None

    def test_are_eq_different_lengths(self):
        """are_eq returns False for arrays of different lengths."""
        assert not smact.are_eq([1.0, 2.0], [1.0, 2.0, 3.0])

    def test_neutral_ratios_iter_no_threshold(self):
        """neutral_ratios_iter raises ValueError when both stoichs and threshold are None."""
        with pytest.raises(ValueError, match="threshold must be an int"):
            list(smact.neutral_ratios_iter([1, -2], stoichs=None, threshold=None))

    def test_site_default_oxidation_states(self):
        """Site with no oxidation_states defaults to [0]."""
        site = smact.lattice.Site([0, 0, 0])
        assert site.oxidation_states == [0]

    # --------- Properties edge cases ---------

    def test_compound_electroneg_none_elements(self):
        """compound_electroneg raises TypeError when elements is None."""
        with pytest.raises(TypeError, match="supply a list of element"):
            compound_electroneg(elements=None, stoichs=[1])

    def test_compound_electroneg_none_stoichs(self):
        """compound_electroneg raises TypeError when stoichs is None."""
        with pytest.raises(TypeError, match="supply stoichiometries"):
            compound_electroneg(elements=["Fe"], stoichs=None)

    def test_compound_electroneg_empty_list(self):
        """compound_electroneg raises TypeError for empty element list."""
        with pytest.raises(TypeError, match="non-empty"):
            compound_electroneg(elements=[], stoichs=[])

    def test_compound_electroneg_pauling_source(self):
        """compound_electroneg with Pauling source works for elements with Pauling data."""
        val = compound_electroneg(elements=["Na", "Cl"], stoichs=[1, 1], source="Pauling")
        assert isinstance(val, float)
        assert val > 0

    def test_compound_electroneg_length_mismatch(self):
        """compound_electroneg raises ValueError when elements and stoichs differ in length."""
        with pytest.raises(ValueError, match="same length"):
            compound_electroneg(elements=["Fe", "O"], stoichs=[1])

    # --------- lattices_are_same coverage ---------

    def test_lattices_are_same(self):
        """lattices_are_same compares ASE-like lattice objects (lines 447-455)."""
        site_a = SimpleNamespace(symbol="Na", position=[0.0, 0.0, 0.0])
        site_b = SimpleNamespace(symbol="Cl", position=[0.5, 0.5, 0.5])
        lattice1 = [site_a, site_b]

        # Same lattice
        site_a2 = SimpleNamespace(symbol="Na", position=[0.0, 0.0, 0.0])
        site_b2 = SimpleNamespace(symbol="Cl", position=[0.5, 0.5, 0.5])
        lattice2 = [site_a2, site_b2]

        assert smact.lattices_are_same(lattice1, lattice2)

        # Different lattice
        site_c = SimpleNamespace(symbol="K", position=[0.0, 0.0, 0.0])
        lattice3 = [site_c, site_b2]
        assert not smact.lattices_are_same(lattice1, lattice3)

    def test_gcd_recursive_single_arg(self):
        """_gcd_recursive with single argument returns that value (line 461)."""
        assert smact._gcd_recursive(7) == 7

    def test_species_no_sse2015_data(self):
        """Species SSE_2015 else branch when element has no SSE_2015 data at all (line 360)."""
        sp = Species("He", 0)
        assert sp.SSE_2015 is None

    # --------- Properties: Pauling with missing eneg, VEC TypeError ---------

    def test_compound_electroneg_pauling_missing_eneg(self):
        """compound_electroneg Pauling source raises ValueError when element lacks Pauling eneg (line 157)."""
        with pytest.raises(ValueError, match="no Pauling electronegativity"):
            compound_electroneg(elements=["He", "Ne"], stoichs=[1, 1], source="Pauling")

    def test_valence_electron_count_none_valence(self):
        """valence_electron_count raises ValueError via TypeError when valence is None (line 213)."""
        with pytest.raises(ValueError, match="Valence data not found"):
            valence_electron_count("Lr")

    # --------- Screening: eneg_states_test_threshold with None ---------

    def test_eneg_states_test_threshold_none_eneg(self):
        """eneg_states_test_threshold returns False when an electronegativity is None."""
        result = smact.screening.eneg_states_test_threshold([1, -1], [None, 3.16], threshold=0)
        assert not result

    def test_smact_validity_mixed_valence_blowup_warning(self):
        """smact_validity warns and returns False when MV expansion exceeds 1M combinations (lines 645-650).

        Fe8O17: gcd(8,17)=1 so the formula is irreducible → stoich=(8,17).
        8*x + 17*(-2) = 0 requires x=4.25 (non-integer), so standard check fails.
        projected = len(Fe_smact14_ox)^8 * len(O_smact14_ox) = 8^8 * 2 ≈ 33M > 1M.
        """
        with pytest.warns(UserWarning, match="too many combinations"):
            result = smact.screening.smact_validity("Fe8O17", mixed_valence=True, oxidation_states_set="smact14")
        assert not result
